# winsqlite3.dll-PowerShell

Use winsqlite3.dll (the SQLite DLL that ships with Windows 10) in PowerShell

More info at https://renenyffenegger.ch/notes/Windows/dirs/Windows/System32/winsqlite3_dll/PowerShell
